#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <windows.h> //poor attempt at trying to change the enconding to fix the problem

int main()
{
    int Name1 = 1;
    int Name = 1;
    Name1 = rand() % 10 + 1;
    Name = rand() % 10 + 1;

    printf("\npress any key to generate a random name \n");
    getch();

    char NameStart1[] = "dan";
    char NameStart2[] = "ste";
    char NameStart3[] = "nat";
    char NameStart4[] = "stu";
    char NameStart5[] = "lin";
    char NameStart6[] = "dal";
    char NameStart7[] = "vel";
    char NameStart8[] = "gals";
    char NameStart9[] = "jens";
    char NameStart10[] = "jen";

    char NameEnd1[] = "na";
    char NameEnd2[] = "pa";
    char NameEnd3[] = "ca";
    char NameEnd4[] = "ra";
    char NameEnd5[] = "art";
    char NameEnd6[] = "vel";
    char NameEnd7[] = "lal";
    char NameEnd8[] = "mal";
    char NameEnd9[] = "no";
    char NameEnd10[] = "su";

    char FinalName1[40];
    char FinalName2[40];

    switch(Name1)
    {
    case 1:
        strcpy(FinalName1, NameStart1);
        break;
    case 2:
        strcpy(FinalName1, NameStart2);
        break;
    case 3:
        strcpy(FinalName1, NameStart3);
        break;
    case 4:
        strcpy(FinalName1, NameStart4);
        break;
    case 5:
        strcpy(FinalName1, NameStart5);
        break;
    case 6:
        strcpy(FinalName1, NameStart6);
        break;
    case 7:
        strcpy(FinalName1, NameStart7);
        break;
    case 8:
        strcpy(FinalName1, NameStart8);
        break;
    case 9:
        strcpy(FinalName1, NameStart9);
        break;
    case 10:
        strcpy(FinalName1, NameStart10);
        break;
    }

    switch(Name)
    {
    case 1 :
        strcpy(FinalName2, NameEnd1);
        break;
    case 2 :
        strcpy(FinalName2, NameEnd2);
        break;
    case 3 :
        strcpy(FinalName2, NameEnd3);
        break;
    case 4 :
        strcpy(FinalName2, NameEnd4);
        break;
    case 5 :
        strcpy(FinalName2, NameEnd5);
        break;
    case 6 :
        strcpy(FinalName2, NameEnd6);
        break;
    case 7 :
        strcpy(FinalName2, NameEnd7);
        break;
    case 8 :
        strcpy(FinalName2, NameEnd8);
        break;
    case 9 :
        strcpy(FinalName2, NameEnd9);
        break;
    case 10 :
        strcpy(FinalName2, NameEnd10);
        break;
    }

    strcat(FinalName1, FinalName2);
    puts(FinalName1);
    main();
}


